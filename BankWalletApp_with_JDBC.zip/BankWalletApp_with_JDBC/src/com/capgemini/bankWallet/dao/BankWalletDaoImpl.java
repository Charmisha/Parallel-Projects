package com.capgemini.bankWallet.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.capgemini.bankWallet.dbutil.BankDbutil;
import com.capgemini.bankWallet.exception.InsufficientBalanceException;
import com.capgemini.bankWallet.model.Account;

public class BankWalletDaoImpl implements BankWalletDao 
{
	
	private Connection con = null;
	PreparedStatement ps;
	@Override
	public boolean saveAccount(Account a) 
	{
		BankDbutil bdb=new BankDbutil();
		con=bdb.getConnection();
		try {
			
			ps=con.prepareStatement("Insert into accountsTable values(?,?,?,?,?,?)");
			ps.setString(1, a.getAccountNo());
			ps.setString(2, a.getName());
			ps.setString(3, a.getMobileNo());
			ps.setString(4, a.getAadharNo());
			ps.setLong(5, a.getAccountBalance());
			ps.setString(6, a.getPin());
			int i=ps.executeUpdate();
			if(i>0)
				return true;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;	
	}

	@Override
	public long viewBalance(String accountNo, String pin) 
	{
	   long balance;
	   BankDbutil bdb=new BankDbutil();
	   con=bdb.getConnection();
       try {
		ps=con.prepareStatement("Select * from accountsTable where AccNum=? and pin=?");
		ps.setString(1, accountNo);
		ps.setString(2,pin);
		ResultSet rs=ps.executeQuery();
		while(rs.next())
		{
			balance=rs.getLong(5);
			return balance;
		}
	} catch (SQLException e) {
		e.printStackTrace();
	}
		return -1;
	}

	@Override
	public long depositCash(String accountNo,long amount) 
	{
		long accBal;
		BankDbutil bdb=new BankDbutil();
		con=bdb.getConnection();
		try {
			ps=con.prepareStatement("select accbal from accountsTable where accnum=?");
            ps.setString(1, accountNo);
            ResultSet rs=ps.executeQuery();
            while(rs.next())
            {            	
            	accBal=rs.getLong(1);
            	ps=con.prepareStatement("update accountsTable set accbal=? where accnum=?");
            	ps.setLong(1, accBal+amount);
            	ps.setString(2, accountNo);
            	int i=ps.executeUpdate();
            	if(i>0)
            	{
            		return accBal+amount;
            	}
            }
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return -1;
	}

	@Override
	public long withdrawCash(String accountNo, String pin,long amount) throws InsufficientBalanceException 
	{
		long accBal;
		BankDbutil bdb=new BankDbutil();
		con=bdb.getConnection();
		try {
			ps=con.prepareStatement("select accbal from accountsTable where accnum=? and pin=?");
            ps.setString(1, accountNo);
            ps.setString(2, pin);
            ResultSet rs=ps.executeQuery();
            while(rs.next())
            {  
            	accBal=rs.getLong(1);
            	if(accBal>=amount)
            	{
            	ps=con.prepareStatement("update accountsTable set accbal=? where accnum=?");
            	ps.setLong(1, accBal-amount);
            	ps.setString(2, accountNo);
            	int i=ps.executeUpdate();
            	if(i>0)
            	{
            		return accBal-amount;
            	}
            	}
            	else throw new InsufficientBalanceException("Insufficient Balance");
            }
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return -1;
	}

	@Override
	public boolean transferMoney(String sourceAcNo, String destAcNo, long amount,String pin) throws InsufficientBalanceException {
		long accBal;
		BankDbutil bdb=new BankDbutil();
		con=bdb.getConnection();
		ResultSet rs;
		int i;
		try {
			ps=con.prepareStatement("select accbal from accountsTable where accnum=? and pin=?");
            ps.setString(1, sourceAcNo);
            ps.setString(2, pin);
            rs=ps.executeQuery();
            while(rs.next())
            {   
            	accBal=rs.getLong(1);
            	if(accBal>=amount)
            	{
            	 ps=con.prepareStatement("update accountsTable set accbal=? where accnum=?");
            	 ps.setLong(1, accBal-amount);
            	 ps.setString(2, sourceAcNo);
            	 i=ps.executeUpdate();
            	 
            	 ps=con.prepareStatement("select accbal from accountsTable where accnum=?");
            	 ps.setString(1, destAcNo);
            	 rs=ps.executeQuery();
            	 while(rs.next())
            	 {
            		 accBal=rs.getLong(1);
            		 ps=con.prepareStatement("update accountsTable set accbal=? where accnum=?");
            		 ps.setLong(1, accBal+amount);
                	 ps.setString(2, destAcNo);
                	 ps.executeUpdate();
            	 }
            	 if(i>0)
            	 {
            		return true;
            	 }
            	
            	}
            	else throw new InsufficientBalanceException("Insufficient Balance");
            }
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

}
